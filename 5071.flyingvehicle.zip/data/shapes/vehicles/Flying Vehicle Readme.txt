Flyer Vehicle

Created by:  Valhalla Entertainment/ The "Chronos V" Team

Web Site: http://www.chronosthegame.com/team.php

Files included
flyer.dts
glider.png
flyervehicle.cs
game.cs
racing.mis (changed the spawn points to spawn in the air)
glider.max
flyer.cfg
flyer.3ds


unzip the files into the starter.racing folder, the files will go into the right folder. make sure it is a fresh head version. The game will start like a normal race game, with one exception. You will be above the ground about 100 mtrs. I added the max file for people to edit to their own specifications.
I only added basic nodes to get it to run.

The max file is for 3dsmax 4

The Berk