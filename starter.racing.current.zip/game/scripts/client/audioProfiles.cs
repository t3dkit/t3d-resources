// ============================================================
// Project            :  starter.racing
// File               :  .\scripts\client\audioProfiles.cs
// Copyright          :  
// Author             :  kent
// Created on         :  Saturday, September 10, 2016 9:59 PM
//
// Editor             :  TorqueDev v. 1.2.5129.4848
//
// Description        :  
//                    :  
//                    :  
// ============================================================


datablock SFXProfile(Sound_Beep1)
{
   fileName = "art/sound/beep1.wav";
   description = Audio2D;
   preload = true;
};

datablock SFXProfile(Sound_Beep2)
{
   fileName = "art/sound/beep2.wav";
   description = Audio2D;
   preload = true;
};