//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Zombie Audio Profiles
//----------------------------------------------------------------------------

// This is the zombie song to play after unleashZombies
//datablock SFXProfile(ZombieSong)
//{
   //filename = "art/sound/zombieSong";
   //description = AudioLoop2d;
//};


//----------------------------------------------------------------------------
// Zombie Player Datablock
//----------------------------------------------------------------------------
datablock PlayerData(MegaZombie)
{
   renderFirstPerson = false;

   computeCRC = false;

   // Third person shape
   shapeFile = "art/shapes/actors/GG_Zombie/MegaZombie.DAE";

   cameraMaxDist = 3;
   
   allowImageStateAnimation = false;

   // No first person arms for stock zombie
   // However, if there was one, the scripts would look like this
   //imageAnimPrefixFP = "zombie";
   //shapeNameFP[0] = "art/shapes/actors/GG_Zombie/FP/FP_ZombieArms.DAE";

   canObserve = 1;
   cmdCategory = "Clients";

   cameraDefaultFov = 55.0;
   cameraMinFov = 5.0;
   cameraMaxFov = 65.0;

   debrisShapeName = "art/shapes/actors/common/debris_player.dts";
   debris = playerDebris;

   aiAvoidThis = 1;

   minLookAngle = "-1.2";
   maxLookAngle = "1.2";
   maxFreelookAngle = 3.0;

   mass = 120;
   drag = 1.3;
   maxdrag = 0.4;
   density = 1.1;
   maxDamage = 80;
   maxEnergy =  60;
   repairRate = 0.33;
   energyPerDamagePoint = 75;

   rechargeRate = 0.256;

   runForce = 4320;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 7;
   maxBackwardSpeed = 1;
   maxSideSpeed = 1;

   sprintForce = 4320;
   sprintEnergyDrain = 0;
   minSprintEnergy = 0;
   maxSprintForwardSpeed = 6;
   maxSprintBackwardSpeed = 2;
   maxSprintSideSpeed = 2;
   sprintStrafeScale = 0.25;
   sprintYawScale = 0.05;
   sprintPitchScale = 0.05;
   sprintCanJump = true;

   crouchForce = 405;
   maxCrouchForwardSpeed = 1.0;
   maxCrouchBackwardSpeed = 0.5;
   maxCrouchSideSpeed = 0.5;

   maxUnderwaterForwardSpeed = 2;
   maxUnderwaterBackwardSpeed = 1;
   maxUnderwaterSideSpeed = 1;

   jumpForce = "747";
   jumpEnergyDrain = 0;
   minJumpEnergy = 0;
   jumpDelay = "15";
   airControl = 0.3;

   fallingSpeedThreshold = -6.0;

   landSequenceTime = 0;
   transitionToLand = false;
   recoverDelay = 0;
   recoverRunForceScale = 0;

   minImpactSpeed = 10;
   minLateralImpactSpeed = 20;
   speedDamageScale = 0.4;

   boundingBox = "0.65 0.75 1.85";
   crouchBoundingBox = "0.65 0.75 1.3";
   swimBoundingBox = "1 2 2";
   pickupRadius = 1;

   // Damage location details
   boxHeadPercentage       = 0.83;
   boxTorsoPercentage      = 0.49;
   boxHeadLeftPercentage   = 0.30;
   boxHeadRightPercentage  = 0.60;
   boxHeadBackPercentage   = 0.30;
   boxHeadFrontPercentage  = 0.60;

   // Foot Prints
   decalOffset = 0.25;

   footPuffEmitter = "LightPuffEmitter";
   footPuffNumParts = 10;
   footPuffRadius = "0.25";

   dustEmitter = "LightPuffEmitter";

   splash = PlayerSplash;
   splashVelocity = 4.0;
   splashAngle = 67.0;
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   bubbleEmitTime = 0.4;
   splashEmitter[0] = PlayerWakeEmitter;
   splashEmitter[1] = PlayerFoamEmitter;
   splashEmitter[2] = PlayerBubbleEmitter;
   mediumSplashSoundVelocity = 10.0;
   hardSplashSoundVelocity = 20.0;
   exitSplashSoundVelocity = 5.0;

   // Controls over slope of runnable/jumpable surfaces
   runSurfaceAngle  = 38;
   jumpSurfaceAngle = 80;
   maxStepHeight = 0.35;  //two meters
   minJumpSpeed = 10;
   maxJumpSpeed = 20;

   horizMaxSpeed = 68;
   horizResistSpeed = 33;
   horizResistFactor = 0.35;

   upMaxSpeed = 80;
   upResistSpeed = 25;
   upResistFactor = 0.3;

   footstepSplashHeight = 0.35;

   //NOTE:  some sounds commented out until wav's are available

   // Footstep Sounds
   FootSoftSound        = FootLightSoftSound;
   FootHardSound        = FootLightHardSound;
   FootMetalSound       = FootLightMetalSound;
   FootSnowSound        = FootLightSnowSound;
   FootShallowSound     = FootLightShallowSplashSound;
   FootWadingSound      = FootLightWadingSound;
   FootUnderwaterSound  = FootLightUnderwaterSound;

   groundImpactMinSpeed    = "45";
   groundImpactShakeFreq   = "4.0 4.0 4.0";
   groundImpactShakeAmp    = "1.0 1.0 1.0";
   groundImpactShakeDuration = 0.8;
   groundImpactShakeFalloff = 10.0;

   observeParameters = "0.5 4.5 4.5";
   class = "Zombie";

   cameraMinDist = "0";
   DecalData = "PlayerFootprint";
   
   // Last attacked player
   lastAttacked = 0;

   // Allowable Inventory Items
   mainWeapon = "";

   maxInv[Lurker] = 0;
   maxInv[LurkerClip] = 0;

   maxInv[LurkerGrenadeLauncher] = 0;
   maxInv[LurkerGrenadeAmmo] = 0;

   maxInv[Ryder] = 0;
   maxInv[RyderClip] = 0;

   maxInv[ProxMine] = 0;

   maxInv[DeployableTurret] = 0;

   // Art pack weapons
   maxInv[Duke] = 0;
   maxInv[DukeClip] = 0;
   maxInv[Mamba] = 0;
   maxInv[MambaClip] = 0;
   maxInv[Disposition] = 0;
   maxInv[DispositionClip] = 0;
   maxInv[Ender] = 0;
   maxInv[EnderAmmo] = 0;
   maxInv[Kraad] = 0;
   maxInv[KraadClip] = 0;
   maxInv[Kral] = 0;
   maxInv[KralClip] = 0;
   maxInv[Kralmok] = 0;
   maxInv[KralmokAmmo] = 0;

   // available skins (see materials.cs in model folder)
   availableSkins =  "base";
};