// Weapon Prices
$LurkerPrice = 100;
$MambaPrice = 150;
$DispositionPrice = 200;
$EnderPrice = 300;

function serverCmdBuyWeapon(%client, %weapon)
{
   // Set the weapon price
   switch$(%weapon)
   {
      case Mamba:
         %weaponPrice = $MambaPrice;
      case Lurker:
         %weaponPrice = $LurkerPrice;
      case Disposition:
         %weaponPrice = $DispositionPrice;
      case Ender:    
         %weaponPrice = $EnderPrice;  
   }
   
   %player = %client.getControlObject(); 
   
   // Check to see if player has enough money to purchase weapon
   if(%player.money >= %weaponPrice)
   {
      %moneyValue = %player.money - %weaponPrice;
      %player.setMoney(%moneyValue);
      // Clear out inventory of purchasable items
      %player.setInventory(Lurker, 0);
      %player.setInventory(Mamba, 0);
      %player.setInventory(Disposition, 0);
      %player.setInventory(Ender, 0);
      
      // Clear all weapons from weapon cycle
      %player.clearWeaponCycle();
      
      // Reset Ryder in cycle
      %player.addToWeaponCycle(Ryder);
      
      // Add newly purchased weapon to inventory and weapon cycle
      %player.setInventory(%weapon, 1);
      %player.setInventory(%weapon.image.clip, %weapon.image.clip.maxInventory);
      %player.setInventory(%weapon.image.ammo, %weapon.image.ammo.maxInventory);    // Start the gun loaded
      %player.addToWeaponCycle(%weapon);
      
      // Set purchased weapon to current weapon
      %player.mountImage(%weapon.image, 0);
   }
}

function enterShop()
{
   GUIshop.setVisible(true);
   showCursor();
}

function leaveShop()
{
   GUIshop.setVisible(false);
   hideCursor();
}