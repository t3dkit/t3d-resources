//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

// How much to drain the energy per update
$FlashlightDrain = 10;

// How often the drain process updates
$FlashlightUpdate = 1000;

// How much energy is drained when destroying a ghost
$FlashlightZap = 25;

function FlashlightClip::onPickup(%this, %obj, %user, %amount)
{
   %user.setEnergyLevel(%obj.getDataBlock().maxEnergy);
}

function Flashlight::onUse(%this, %obj)
{
   // Act like a weapon on use
   Weapon::onUse( %this, %obj );
}

function Flashlight::onPickup( %this, %obj, %shape, %amount )
{
   // Act like a weapon on pickup
   Weapon::onPickup( %this, %obj, %shape, %amount );
}

function Flashlight::onInventory( %this, %obj, %amount )
{
   %obj.client.setAmmoAmountHud( 1, %amount );

   // Cycle weapons if we are out of ammo
   if ( !%amount && ( %slot = %obj.getMountSlot( %this.image ) ) != -1 )
      %obj.cycleWeapon( "prev" );
}

function FlashlightWeaponImage::onMount( %this, %obj, %slot )
{
   echo("@@@ Flashlight onMount");
   if(%obj.getEnergyLevel() <= 0)
   {
      echo("@@@ No energy for flashlight");
      %obj.flashLightEnabled = false;
      return;
   }
   
   %obj.flashLightEnabled = true;
   
   if(!isObject(%obj.flashLightObject))
   {
      %obj.flashLightObject = new SpotLight()
      {
         range = 15;
         cookie = "art/textures/Decals/Light.png";
         castShadows = true;
         innerAngle = 30;
         outerAngle = 45;
      };
   }
   
   %obj.flashLightObject.setLightEnabled(1);
   %obj.mountObject(%obj.flashLightObject, 0, "0.05 0.68 -0.09");
   
   %obj.schedule($FlashlightUpdate, "drainBattery");
}

function FlashlightWeaponImage::onUnmount( %this, %obj, %slot )
{
   %obj.client.RefreshWeaponHud( 0, "", "" );
   
   if(isObject(%obj.flashLightObject))
   {
      %this.flashLightEnabled = false;
      %this.flashLightObject.setLightEnabled(0);
   }
}

function Player::enableFlashLight(%this)
{
   %this.flashLightEnabled = true;
   
   if(!isObject(%this.flashLightObject))
   {
      %this.flashLightObject = new SpotLight()
      {
         range = 15;
         cookie = "art/textures/Decals/Light.png";
         castShadows = true;
         innerAngle = 30;
         outerAngle = 45;
      };
   }
   %this.flashLightObject.setLightEnabled(1);
   %this.mountObject(%this.flashLightObject, 0, "0.05 0.68 -0.09");
}

function Player::disableFlashLight(%this)
{
   if(isObject(%this.flashLightObject))
   {
      %this.flashLightEnabled = false;
      %this.flashLightObject.setLightEnabled(0);
   }
}

function Player::drainBattery(%this)
{   
   if(%this.getEnergyLevel() <= 0)
   {
      echo("@@@ Battery is dead");
      %this.disableFlashLight();
      return;
   }
   
   %newBatteryLevel = %this.getEnergyLevel() - $FlashlightDrain;
   
   echo("@@@ Energy level: " @ %this.getEnergyLevel());
   
   %this.setEnergyLevel(%newBatteryLevel);
   
   // UPDATE HUD HERE
   
   %this.schedule($FlashlightUpdate, "drainBattery");
}