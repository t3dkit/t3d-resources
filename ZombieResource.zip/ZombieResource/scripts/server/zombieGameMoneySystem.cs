function Player::getMoney(%this)
{
   return %this.money;  
   //echo(%this.className);
}

function Player::setMoney(%this, %amount)
{
   %this.money = %amount;
   commandToClient(%this.client, 'UpdateCash', %amount);
}

function Player::updateMoney(%this, %damageLocation)
{
   %droppedMoney = getRandom(10, 25);

   if(%damageLocation $= "head")
      %droppedMoney *= 2;   
   
   echo("@@@ New Money: " @ %droppedMoney);
   
   %totalAmount = %this.getMoney() + %droppedMoney;
   
   echo("@@@ Money total: " @ %totalAmount);
   
   %this.setMoney(%totalAmount);
}