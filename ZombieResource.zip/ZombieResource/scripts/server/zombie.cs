//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

//--------------------------------------
// Global arrays containing zombie parts
//--------------------------------------
new SimSet(ZombieSet);

$TimeLapseSpeed = 30000;

$CurrentZombieCount = 0;
$TotalZombieCount = 0;

$WaveLimter = 1;
$CurrentWaveNumber = 0;
$TotalWaveCount = 0;

$RoundNumber = 1;

new ArrayObject(ZombieHair);
new ArrayObject(ZombieHeads);
new ArrayObject(ZombieShirts);
new ArrayObject(ZombieArms);
new ArrayObject(ZombieHands);
new ArrayObject(ZombiePants);
new ArrayObject(ZombieAccessories);

ZombieShirts.push_back(0, "zombie_tshirt_torn_LOD");
ZombieShirts.push_back(1, "zombie_tshirt_LOD");
ZombieShirts.push_back(2, "zombie_shirt_long_sleeve_LOD");
ZombieShirts.push_back(3, "zombie_jacket_LOD");

ZombiePants.push_back(0, "zombie_pants_torn_LOD");
ZombiePants.push_back(1, "zombie_pants_LOD");

ZombieHeads.push_back(0, "zombie_head_01_LOD");
ZombieHeads.push_back(1, "zombie_head_02_LOD");
ZombieHeads.push_back(2, "zombie_head_03_LOD");
ZombieHeads.push_back(3, "zombie_head_04_LOD");

ZombieHands.push_back(0, "zombie_hands_LOD");

ZombieHair.push_back(0, "zombie_hair_01_LOD");
ZombieHair.push_back(1, "zombie_hair_02_LOD");
ZombieHair.push_back(2, "zombie_hair_03_LOD");
ZombieHair.push_back(3, "zombie_hair_04_LOD");
ZombieHair.push_back(4, "zombie_hair_05_LOD");

ZombieArms.push_back(0, "zombie_arms_right_nub_LOD");
ZombieArms.push_back(1, "zombie_arms_nubs_LOD");
ZombieArms.push_back(2, "zombie_arms_left_nub_LOD");
ZombieArms.push_back(3, "zombie_arms_LOD");

// This is used for controlling random cycling (debug only)
$TimeLapseSpeed = 3000;


//-----------------------------------
// Base datablock functions
//-----------------------------------

// Called when a zombie is spawned
function Zombie::onAdd(%this, %obj)
{
   // Immediately hide the mesh so we can reconstruct it
   %obj.setAllMeshesHidden(1);
   
   %sequenceNumber = getRandom(1, 3);
   %sequence = "root" @ %sequenceNumber;
   
   %obj.setActionThread(%sequence, 1);
   %obj.buildZombie();
   
   // Vehicle timeout
   %obj.mountVehicle = false;
   
   // Set AI variables
   %obj.mMoveTolerance = "0.8";
   %obj.moveStuckTolerance = "0.001";

   // Set states
   %obj.isAttacking = false;
   %obj.isMoving = false;
   %obj.LockedOn = false;
   %obj.thinkCycle = "";
   %obj.isSprinting = (getRandom(0, 20) % 4);
   
   // This schedule is used for testing zombie generator, not game play
   //%obj.randomThread = %obj.schedule($TimeLapseSpeed, zombieRandom);
   
   // Start the zombie AI thinker
   %obj.thinkCycle = %obj.schedule(1000, zombieThink);
   
   // Add this zombie to a global set for tracking
   ZombieSet.add(%obj);
}

// Called when a zombie is removed
function Zombie::onRemove(%this, %obj)
{
   ZombieSet.remove(%obj);
   
   if (%obj.client.player == %obj)
      %obj.client.player = 0;
   
   if(%obj.thinkCycle !$= "")   
      cancel(%obj.thinkCycle);
}

//--------------------------------------
// Zombie Generator Functions
//--------------------------------------

// Constructs a zombie out of the mesh sets (declared at the top of this file)
function AIPlayer::buildZombie(%this)
{
   // Hair
   %randomIndex = getRandom(0, ZombieHair.count()-1);
   %randomValue = ZombieHair.getValue(%randomIndex);
   %this.setMeshHidden(%randomValue, 0);
   %this.hairMesh = %randomValue;
   
   // Head
   %randomIndex = getRandom(0, ZombieHeads.count()-1);
   %randomValue = ZombieHeads.getValue(%randomIndex);
   %this.setMeshHidden(%randomValue, 0);
   %this.headMesh = %randomValue;
   
   // Shirt
   %randomIndex = getRandom(0, ZombieShirts.count()-1);
   %randomValue = ZombieShirts.getValue(%randomIndex);
   %this.setMeshHidden(%randomValue, 0);
   
   // If the shirt was a long sleeve variant, use the hands mesh
   // Otherwise, hide them and pick a random arm set
   if(%randomValue $= "zombie_jacket_LOD" || %randomValue $= "zombie_shirt_long_sleeve_LOD")
   {
      %this.setMeshHidden("zombie_hands_LOD", 0);
   }
   else
   {
      %this.setMeshHidden("zombie_hands_LOD", 1);
      
      // Arms
      %randomIndex = getRandom(0, ZombieArms.count()-1);
      %randomValue = ZombieArms.getValue(%randomIndex);
   
      %this.setMeshHidden(%randomValue, 0);
   }
   
   // Legs
   %randomIndex = getRandom(0, ZombiePants.count()-1);
   %randomValue = ZombiePants.getValue(%randomIndex);
   %this.setMeshHidden(%randomValue, 0);
}

// Used for testing zombie generator
function AIPlayer::zombieRandom(%this)
{
   %this.setAllMeshesHidden(1);
   %this.buildZombie();
   
   %this.randomThread = %this.schedule($TimeLapseSpeed, zombieRandom);
}

//-----------------------------------
// Damage resolution
//-----------------------------------
function Zombie::damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
{
   // Get the player that last attacked the zombie.
   %obj.lastAttacked = %sourceObject.sourceObject;
   
   if (!isObject(%obj) || %obj.getState() $= "Dead" || !%damage)
      return;

   %obj.applyDamage(%damage);
   
   %obj.damageLocation = firstWord(%obj.getDamageLocation( %position ) );
   
   if(%obj.damageLocation $= "head")
   {
      %obj.setMeshHidden(%obj.hairMesh, 1);
      %obj.setMeshHidden(%obj.headMesh, 1);
      %obj.setMeshHidden("zombie_head_05_LOD", 0);
   }

   // Deal with client callbacks here because we don't have this
   // information in the onDamage or onDisable methods
   %client = %obj.client;
   %sourceClient = %sourceObject ? %sourceObject.client : 0;

   if (isObject(%client))
   {
      // Determine damage direction
      if (%damageType !$= "Suicide")
         %obj.setDamageDirection(%sourceObject, %position);

      if (%obj.getState() $= "Dead")
         %client.onDeath(%sourceObject, %sourceClient, %damageType, %location);
   }
}

function Zombie::onDamage(%this, %obj, %delta)
{
   // This method is invoked by the ShapeBase code whenever the
   // object's damage level changes.
   if (%delta > 0 && %obj.getState() !$= "Dead")
   {
      // Apply a damage flash
      %obj.setDamageFlash(1);

      // If the pain is excessive, let's hear about it.
      if (%delta > 10)
         %obj.playPain();
   }
}

function Zombie::onDisabled(%this, %obj, %state)
{
   cancel(%this.thinkCycle);
      
   %obj.stop();
   %obj.clearAim();
   
   %obj.isAttacking = false;
   %obj.LockedOn = false;
   %obj.isSprinting = false;
   
   $CurrentZombieCount--;

   %obj.playZombieDeathAnimation();

   // Schedule corpse removal. Just keeping the place clean.
   %obj.schedule($CorpseTimeoutValue - 1000, "startFade", 1000, 0, true);
   %obj.schedule($CorpseTimeoutValue, "delete");

   echo("LasAttacked: " @ %obj.lastAttacked);
   // Update the players money that killed it.
   %obj.lastAttacked.updateMoney(%obj.damageLocation);   
   
   if(!$CurrentZombieCount)
   {
      if($CurrentWaveNumber < $WaveLimter)
      {
         echo("@@@ Starting wave " @ $CurrentWaveNumber);
         
         for (%clientIndex = 0; %clientIndex < ClientGroup.getCount(); %clientIndex++)
         {
            %cl = ClientGroup.getObject(%clientIndex);
            commandToClient(%cl, 'updateRoundWaves', $RoundNumber, $CurrentWaveNumber);
         }
         
         schedule(5000, 0, "unleashZombies");
      }
      else
      {
         $RoundNumber++;
         echo("@@@ Starting round " @ $RoundNumber);
         
         $CurrentWaveNumber = 0;
         
         for (%clientIndex = 0; %clientIndex < ClientGroup.getCount(); %clientIndex++)
         {
            %cl = ClientGroup.getObject(%clientIndex);
            commandToClient(%cl, 'updateRoundWaves', $RoundNumber, $CurrentWaveNumber);
         }
         
         %roundRemainder = $RoundNumber % 4;
         if(%roundRemainder == 0)
         {
            echo("@@@ Increasing wave limit to " @ $WaveLimter);
            $WaveLimter++;
         }
         schedule(20000, 0, "unleashZombies");
      }
   }
   
}

function Zombie::kill(%this, %damageType)
{
   %this.damage(0, %this.getPosition(), 10000, %damageType);
}

function AIPlayer::playZombieDeathAnimation(%this)
{
   %numDeathAnimations = %this.getNumDeathAnimations();
   
   if ( %numDeathAnimations > 0 )
   {
      if (isObject(%this.client))
      {
         if (%this.client.deathIdx++ > %numDeathAnimations)
            %this.client.deathIdx = 1;
         %this.setActionThread("Death" @ %this.client.deathIdx);
      }
      else
      {
         %rand = getRandom(1, %numDeathAnimations);
         %this.setActionThread("Death" @ %rand);
      }
   }
}

//-----------------------------------
// Zombie AI
//-----------------------------------
function AIPlayer::zombieThink(%this)
{
   // Check to see if the zombie is dead
   // if it is, stop thinking
   if(%this.getState() $= "Dead")
   {
      cancel(%this.thinkCycle);
      
      %this.stop();
      %this.clearAim();
      
      %this.isAttacking = false;
      %this.LockedOn = false;
      
      return;
   }
   
   // The zombie has a target, one track mind reaction follows
   if(%this.LockedOn == true)
   {
      // Find out who the target is
      %target = %this.getAimObject();
      
      // If the target is invalid (either dead or disconnected), stop tracking
      if(%target == -1)
      {
         %this.clearAim();
         %this.LockedOn = false;
         %this.thinkCycle = %this.schedule(500, zombieThink);
         
         %sequenceNumber = getRandom(1, 3);
         %sequence = "root" @ %sequenceNumber;
   
         %this.setActionThread(%sequence, 1);
         
         return;
      }
      
      // Find out how far away the target is
      %distance = %this.getTargetDistance(%target);
      
      // If the target is close enough
      if(%distance < 1.5)
      {
         // Stop and set attacking state
         %this.stop();
         
         // Start attacking (nom nom)
         if(!%this.attacking)
            %this.attacking = true;
               
         %sequenceNumber = getRandom(1, 2);
         %sequence = "attack" @ %sequenceNumber;
         %this.setActionThread(%sequence, 1);
   
         %id = %this.getId();
         %position = %this.getPosition();
         
         %target.schedule(100, "damage", %id, %position, "5", "\"BulletProjectile\"");
         
         //%target.damage(%this, %this.getPosition(), 5, "BulletProjectile");
      }
      else
      {
         // Not close enough to do anything but...
         
         // If zombie was attacking previously, stop doing so since the target
         // has moved out of range
         if(%this.attacking)
         {
            %this.attacking = false;
            %this.stopZombieAttack();
            return;
         }
         
         // Constantly move toward target if it is out of range
         %this.setMoveDestination(%target.getPosition(), 0);
      }
      
      // Continue to think 
      %this.thinkCycle = %this.schedule(500, zombieThink);
      return;
   }
   
   // With no target, start scanning the area within 20 meters for a player
   InitContainerRadiusSearch(%this.getPosition(), 20, $TypeMasks::PlayerObjectType);
   
   // Iterate through the container's search result
   while ((%targetObject = containerSearchNext()) != 0)
   {
      // If a player is located and it is NOT an AIPlayer (other zombies)
      // begin lockon/tracking
      if(%targetObject.isMemberOfClass("Player") && !%targetObject.isMemberOfClass("AIPlayer"))
      {
         // Target the player
         %this.setAimObject(%targetObject);
         
         // If it is a fast zombie
         if(%this.isSprinting)
         {
            // 85 is a good speed that matches the sprint anims
            %this.setMoveSpeed(85);
            
            // Pick a random sprint anim
            %sequenceNumber = getRandom(1, 2);
            %sequence = "sprint" @ %sequenceNumber;
            %this.setActionThread(%sequence, 1);
         }
         else
         {
            // This is a slow zombie, so go with a shamble speed
            // Anything above 0.04 makes the zombie look like it is gliding
            %this.setMoveSpeed(0.04);
            
            // Pick a random shamble ("run#") sequence
            %sequenceNumber = getRandom(1, 2);
            %sequence = "run" @ %sequenceNumber;
            %this.setActionThread(%sequence, 1);
         }
         
         // Target acquired, set state
         %this.LockedOn = true;
         
         // Continue thinking
         %this.thinkCycle = %this.schedule(200, zombieThink);
         return;
      }
   }
   
   // Catch all think cycle
   %this.thinkCycle = %this.schedule(1000, zombieThink);
}

// Called when the zombie was previously attacking, but target moved out of range
function AIPlayer::stopZombieAttack(%this)
{
   // If it's a sprinting zombie (scary)
   if(%this.isSprinting)
   {
      // Pick and set a random sprint animation
      %sequenceNumber = getRandom(1, 2);
      %sequence = "sprint" @ %sequenceNumber;
      %this.setActionThread(%sequence, 1);
      %this.thinkCycle = %this.schedule(100, zombieThink);
   }
   else
   {
      // Slow zombie should get a random shamble ("run") animation
      %sequenceNumber = getRandom(1, 2);
      %sequence = "run" @ %sequenceNumber;
      %this.setActionThread(%sequence, 1);
      %this.thinkCycle = %this.schedule(100, zombieThink);
   }
}

// Simple attack function that triggers the animation and applies damage
function AIPlayer::zombieAttack(%this, %target)
{
   
}

// Return how far the target is from the zombie
function AIPlayer::getTargetDistance(%this, %target)
{
   %tgtPos = %target.getPosition();
   %eyePoint = %this.getWorldBoxCenter();
   %distance = VectorDist(%tgtPos, %eyePoint);
   
   return %distance;
}

// Find the closest Player object on the server, regardless of range or targeting
function AIPlayer::getNearestPlayerTarget(%this)
{
   echo("\c4AIPlayer::getNearestPlayerTarget("@ %this @")");

   %index = -1;
   %botPos = %this.getPosition();
   %count = ClientGroup.getCount();
   for(%i = 0; %i < %count; %i++)
   {
      %client = ClientGroup.getObject(%i);
      if (%client.player $= "" || %client.player == 0)
         return -1;
      %playerPos = %client.player.getPosition();

      %tempDist = VectorDist(%playerPos, %botPos);
      if (%i == 0)
      {
         %dist = %tempDist;
         %index = %i;
      }
      else
      {
         if (%dist > %tempDist)
         {
            %dist = %tempDist;
            %index = %i;
         }
      }
   }
   return %index;
}

//-----------------------------------
// Zombie movement
//-----------------------------------

// Zombie has collided with something
function Zombie::onCollision(%this, %obj, %col, %fade, %pos, %normal)
{
   if (!isObject(%col) || %obj.getState() $= "Dead")
      return;
   
   // If it's a player, stop just in case
   if(%col.isMemberOfClass("Player") && !%obj.isAttacking && !%col.isMemberOfClass("AIPlayer"))
   {  
      // Stop moving
      %obj.stop();
      
      // Regardless of the original target, attack the unlucky soul
      // that was dumb enough to get in the way
      %obj.setAimObject(%col);
   }
}

// Zombie is stuck on something, being too dumb to hop or crawl over
function Zombie::onMoveStuck(%this,%obj)
{
   // MPTODO - Get this smoothed out with Recast
   echo( %obj @ " onMoveStuck" );
   %obj.stop();
}

// Used to simulate Dawn of the Dead movement (horrifying)
// regardless of original movement scheme
function AIPlayer::sprint(%this)
{
   // Pick a random sprint animation to use
   %sequenceNumber = getRandom(1, 2);
   %sequence = "sprint" @ %sequenceNumber;
   %this.setActionThread(%sequence, 1);
}

//-----------------------------------
// Zombie Spawning
//-----------------------------------

// Find a random spawn sphere from the ZombieSpawners SimGroup (must exist in level)
function getRandomZombieSpawner()
{
   if(isObject(ZombieSpawners))
      return ZombieSpawners.getRandom();
}

// Create an individual zombie at the specified %spawnPoint (SpawnSphere)
function spawnZombie(%spawnPoint)
{
   // Use the MegaZombie player datablock
   %zombie = spawnObject("AIPlayer", "MegaZombie");
   
   // Set the zombie's original spawn point
   // This is used for spawning a new zombie after this one dies
   %zombie.spawnPoint = %spawnPoint;

   // If we have an object do some initial setup
   if (isObject(%zombie))
   {
      // Set the transform to %spawnPoint's transform
      %zombie.setTransform(%spawnPoint.getTransform());
      $CurrentZombieCount++;
      $TotalZombieCount++;
   }
   
   MissionCleanup.add(%zombie);
}

// Global function used to spawn a zombie at every SpawnSphere that exists
// in the ZombieSpawners group
function unleashZombies()
{
   // A SimGroup named ZombieSpawners (containing spawn spheres) must exist
   if(!isObject(ZombieSpawners))
      return;
      
   // Find out how many zombie spawners there are
   %spawnPointCount = ZombieSpawners.getCount();
   
   // Loop through all the zombie spawners
   for(%i = 0; %i < %spawnPointCount; %i++)
   {
      // Get a spawnpoint
      %spawnPoint = ZombieSpawners.getObject(%i);
      
      // Create a zombie at the %spawnPoint
      spawnZombie(%spawnPoint);
   }
   
   $CurrentWaveNumber++;
   
   $TotalWaveCount++;
   
   for (%clientIndex = 0; %clientIndex < ClientGroup.getCount(); %clientIndex++)
   {
      %cl = ClientGroup.getObject(%clientIndex);
      commandToClient(%cl, 'updateRoundWaves', $RoundNumber, $CurrentWaveNumber);
   }
   
   // PLAY ZOMBIE MUSIC HERE
   //schedule(3000, 0, "sfxPlay", "ZombieSong");
}