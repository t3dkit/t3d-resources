$NPC::Attack=1;
$NPC::Defend=2;
$NPC::Spell=3;
$NPC::Arts=4;
$NPC::Item=5;
$NPC::Waiting=6;
$NPC::Idle=7;
$NPC::Moving=8;
$NPC::PickDestionation=9;
$NPC::Init=10;
$NPC::ViaPoint=11;
$NPC::Captured=12;
$NPC::LostSite=13;
$NPC::SetupMode=14;
$NPC::StaticMode=15;
$NPC::PickPath=16;

 $AIPlayer::Obstacles =   
   $TypeMasks::PlayerObjectType |      // other players, not the target  
   $TypeMasks::StaticTSObjectType |    // trees and whatnot  
   $TypeMasks::InteriorObjectType;     // walls  
   
$AIPlayer::ByPass = $TypeMasks::StaticTSObjectType;
$AIPlayer::PlayerMask = $TypeMasks::PlayerObjectType; 

 datablock PlayerData(NPCMale : Player)  
 {  
      category= "NPC_CHARACTERS"; // Add to editor  
      shapeFile = "art/shapes/players/BaseMale/BaseMale.dts"; //Your Desired Chatacter Model
      
   mass = 90;
   drag = 0.3;
   maxdrag = 0.4;
   density = 100;
   maxDamage = 100;
   maxEnergy =  60;
   repairRate = 0.33;
   energyPerDamagePoint = 5.0;
 };  

function PlayerData::create(%block)
{
      %obj = new AIPlayer() {  
        dataBlock = %block;  
        aiPlayer = true;  
        DestinationX=0;//Do not modify
        DestinationY=0;//Do not modify
        Origin=0;//Do not modify
        OriginX=0;//Do not modify
        OriginY=0;//Do not modify
        CurrentState = $NPC::SetupMode;//set to init value '10' when ready to activate AI
        MovementRadius=10;//Do what you want
        MovementDistance=6;//Do what you want
        MovementSpeed=0.5;//Do what you want cant go higher than 1
        RunSpeed=1;//Do what you want cant go higher than 1
        WaitTime=5000;// in milliseconds
        ThinkSpeed=500;//can not be 0, in milliseconds
        target=0;//do not change
        CanAttack=1;// 0 = NPC  1 = MOB
        CanRespawn=0; //Weather or not the MOB can respawn after its caught you.
        ViaPoint=0;//do not change
        JumpHeight=10; // 10 is a off the wall guess of how high the npc can jump
        GlossaryName="NPC_Enemy";//do not change
        RespawnTime=8000; //Respawn time in milliseconds
        AggroRadius=10; //Maximum range of detection
        scheduleHandel=0;  //do not change
        waitloops=0;//do not change
        AIMode=1; // 1= Wander Mode 2=Path Mode 3 = Static Mode
        StaticModePose="root"; //Name of the animation for static pose
        StaticLoop=0;  // if you want the animation to look every few seconds AKA Idle animations or repeated animation flow.
        StaticLoopTime=2; //in seconds till repeat animation
        FollowPathCurrentDir=true; //Do not modify tells weather not is going forwards or backwards through the path
        FollowPathCount=5;//How many waypoints are in the path foler to follow
        FollowPathCurrentNum=0;//Do not modify
        FollowPaths="-1"; //The name of the 'SimGroup' that has the pathe the bot will follow
        FollowLoop=0; // seather the path will be followed in a circle pattern or back and forward. 1= Circle 0 = end to end
    };
  return(%obj);
}

function AIPlayer::onMoveStuck(%this, %obj){
   %obj.setMoveDestination(" "@ %obj.OriginX @" "@ %obj.OriginY @" "@0,true);
}
function NPCMale::onReachDestination(%this, %obj){
   if(%obj.CurrentState == $NPC::Moving){
      cancel(%obj.scheduleHandel);
      %obj.setMoveSpeed(%obj.MovementSpeed);
      if(%obj.AIMode == 1 || %obj.AIMode == 2){
         %obj.CurrentState=$NPC::Waiting;
      }else{
         %obj.CurrentState=$NPC::StaticMode;
      }
      %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
   }
}
function NPCMale::onAdd(%this,%obj)  
{
   cancel(%obj.scheduleHandel);
   %obj.CurrentState=$NPC::Init;

  %obj.mountImage( RocketLauncherImage, 0 );
  %obj.setImageAmmo( 0, 1 );
  
   %obj.scheduleHandel= %obj.schedule(50, "think",%obj);
}  
function AIPlayer::findNextPath(%obj){
      %pathGroupName = "MissionGroup/"@%obj.FollowPaths;
      %paths = nameToID(%pathGroupName);

        if (%paths != -1)
        {
            %count = %paths.getCount();
            if (%count != 0)
            {
               for(%i=0;%i<%count;%i++){
               %path = %paths.getObject(%i);
                  if(%path.name $= (%obj.FollowPaths@"_"@%obj.FollowPathCurrentNum)){
                     break;
                  }
               }
            }
         }
      
      if(isObject(%path)){
         %obj.setMoveDestination(%path.getTransform(),true);
         %obj.CurrentState = $NPC::Moving;
         %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
      }else{
         //echo("Error: AI path not found");
      }
      if(!%obj.FollowLoop){
         if(%obj.FollowPathCurrentDir){
            %obj.FollowPathCurrentNum++;
         }else{
            %obj.FollowPathCurrentNum--;
         }
      }else{
         %obj.FollowPathCurrentNum++;
      }
      if(%obj.FollowPathCurrentNum==%obj.FollowPathCount ){
         if(!%obj.FollowLoop){
            %obj.FollowPathCurrentNum--;
            %obj.FollowPathCurrentNum--;
            %obj.FollowPathCurrentDir=false;
         }else{
            %obj.FollowPathCurrentNum=0;
         }
      }
      if(%obj.FollowPathCurrentNum<0){
         if(!%obj.FollowLoop){
            %obj.FollowPathCurrentNum=0;
            %obj.FollowPathCurrentDir=true;
         }
      }
         
}
function AIPlayer::WanderSomewhere(%this, %obj){
   %Xpos=0;
   %Ypos=0;   
   %xfrm = %obj.getTransform();
   %charX=getWord(%xfrm,0);
   %charY=getWord(%xfrm,1);
   %distance=%obj.MovementDistance;
   %WanderMinX=%obj.OriginX-%obj.MovementRadius;
   %WanderMaxX=%obj.OriginX+%obj.MovementRadius;
   %WanderMinY=%obj.OriginY-%obj.MovementRadius;
   %WanderMaxY=%obj.OriginY+%obj.MovementRadius;
   
   while(1){
    %direction=(6.28/360)*(getRandom(0,360));
    %Xpos= mCos(%direction)*%distance;
    %Ypos= mSin(%direction)*%distance;
    if(
    %charX+%Xpos >= %WanderMinX &&
    %charX+%Xpos <= %WanderMaxX &&
    %charY+%Ypos >= %WanderMinY &&
    %charY+%Ypos <= %WanderMaxY )
    {
      %obj.DestinationX=%charX+%Xpos;
      %obj.DestinationY=%charY+%Ypos;
      %obj.setMoveDestination(" "@ %charX+%Xpos @" "@ %charY+%Ypos @" "@0,true);
      break;    
    }else{
      //Return to Origin
      %obj.setMoveDestination(" "@ %obj.OriginX @" "@ %obj.OriginY @" "@0,true);
      break;
    }
   }
}
function AIPlayer::CheckEnemy(%this, %obj)
{
         %enemy = containerFindFirst($AIPlayer::PlayerMask, %obj.getPosition(),%obj.AggroRadius,%obj.AggroRadius,%obj.AggroRadius);
         //echo("Starting Loop....");   
         while(%enemy>-1&& %enemyold!=%enemy)
         {
            %name = %enemy.GlossaryName;
            //echo(%name);   
               if(%name $= "PlayableCharacter") 
               {
                  %obj.target=%enemy;
                  %obj.setMoveDestination(%obj.target.getTransform(),true);
                  %obj.CurrentState=$NPC::Attack;
                 
                  %obj.setAimObject(%obj.target); //look at the client   
                  %obj.setImageTrigger(0,true); //make it shoot    
    

                  return true;
                  break;
               }
               else
               {
                  %enemyold=%enemy;
                  %enemy =  containerFindNext();
               }
         }         
         return false;
}
function AIPlayer::isPathToTargetClear(%this, %obj)
{
   cancel(%obj.scheduleHandel);
	%obstruction = %obj.clearView(%obj,%obj.target);
	
	if(%obstruction > -1){
		
		%xfrm = %obj.getTransform(); 
		%charX=getWord(%xfrm,0); 
		%charY=getWord(%xfrm,1); 
		%charZ=getWord(%xfrm,2); 
		%ZJumpMin=%charZ+%Obj.JumpHeight;

		%xfrmOBS = %obstruction.getTransform(); 
		%charXOBS=getWord(%xfrmOBS,0); 
		%charYOBS=getWord(%xfrmOBS,1); 
		%charZOBS=getWord(%xfrmOBS,2); 
		%ZJumpMinOBS=%charZOBS+%Obj.JumpHeight;

		%targetsearch = containerRayCast(%charX@","@%cahrY@","@%ZJumpMin, %charXOBS@","@%cahrYOBS@","@%ZJumpMinOBS, $AIPlayer::Obstacles, %obj);  
      %impactpoint = firstWord(%targetsearch);   
       if(%impactpoint == %obstruction){
            %waypoint = containerFindFirst($AIPlayer::ByPass, %impactpoint.getPosition(),0,3000,0);
            %loopcount =0;            
            while(true){
               if(%waypoint.name $= "ViaPoint"){
                  if(%obj.clearView(%obj,%waypoint) == -1 || %loopcount==1){
                     %obj.ViaPoint=%waypoint;
                     %obj.setMoveDestination(%waypoint.getPosition(),true);
                     %obj.CurrentState=$NPC::ViaPoint;
                     %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
                     return false;                 
                     break;
                  }else{
                     %waypoint =  containerFindNext();
                     %loopcount++;
                  }
               }
            }
       }else{
            %obj.ViaPoint=%obstruction;
            %obj.CurrentState=$NPC::JumpPoint;
            %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
            return false;
       }
	}
	return true;
}

function AIPlayer::clearView(%this, %obj,%tgt)  
{  
    if(!isObject(%tgt)) return false;  
		%xfrmOBS = %obj.getTransform(); 
		%charXOBS=getWord(%xfrmOBS,0); 
		%charYOBS=getWord(%xfrmOBS,1); 
		%charZOBS=getWord(%xfrmOBS,2); 
   
		%xfrm = %tgt.getTransform(); 
		%charX=getWord(%xfrm,0); 
		%charY=getWord(%xfrm,1); 
		%charZ=getWord(%xfrm,2); 
    %targetsearch = containerRayCast(%charXOBS@","@%charXOBS@","@%charZOBS, %charX@","@%cahrY@","@%charZ, $AIPlayer::Obstacles, %obj);  
    %impactpoint = firstWord(%targetsearch);  
    if(%impactpoint == %tgt){
	return -1;	
    } else if(%impactpoint == 0){
        return -2;
    }else{
	return %impactpoint;
    }
    
}  

function AIPlayer::respawn(%this, %obj)
{
   if(%obj.CanRespawn){
   cancel(%obj.scheduleHandel);
   %obj.setTransform(%obj.Origin);
   %obj.CurrentState=$NPC::Init;
   %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
   %obj.startFade(1000, 0, false );
   }else{
      %obj.CurrentState=$NPC::Idle;
   }
}

function AIPlayer::think(%this,%obj){
   cancel(%obj.scheduleHandel);
   switch(%obj.CurrentState){
      case $NPC::Attack :
         //if(%obj.isPathToTargetClear(%obj)){
            %obj.setAimObject(%obj.target); //look at the client
            %obj.setImageTrigger(0,true); //make it shoot 
            %obj.setMoveSpeed(%obj.RunSpeed);
            %obj.setMoveDestination(%obj.target.getPosition(),true);
            %distance = VectorDist( %obj.target.getTransform(),%obj.getTransform() );
            if(%distance<3){
               cancel(%obj.moveSchedule);
               %obj.CurrentState=$NPC::Captured;
            }else if(%distance>20){
               cancel(%obj.moveSchedule);
               %obj.setImageTrigger(0,false); //make it stop shoot 
               %obj.CurrentState=$NPC::LostSite;
            }else{
               cancel(%obj.moveSchedule);
               %distance = VectorDist( %obj.Origin,%obj.getTransform() );
               if(%distance>20){
                  %obj.setImageTrigger(0,false); //make it stop shoot 
                  %obj.CurrentState=$NPC::LostSite;
               }
            }
            %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
         //}
      case $NPC::Waiting : 
         if(%obj.CanAttack)
         {
            if(%obj.CheckEnemy(%obj))
            {
               %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
            }
            else
            {
               %obj.waitloops++;
               if(%obj.waitloops>(%obj.WaitTime/%obj.ThinkSpeed)){
                  %obj.waitloops=0;
                  if(%obj.AIMode == 1){
                     %obj.CurrentState=$NPC::PickDestionation;
                     %obj.scheduleHandel= %obj.schedule(%obj.WaitTime, "think",%obj);
                  }else if(%obj.AIMode == 2){
                     %obj.CurrentState=$NPC::PickPath;
                     %obj.scheduleHandel= %obj.schedule(%obj.WaitTime, "think",%obj);
                  }
               }
               %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
            }
         }else{
            if(%obj.AIMode == 1){
               %obj.CurrentState=$NPC::PickDestionation;
               %obj.scheduleHandel= %obj.schedule(%obj.WaitTime, "think",%obj);
            }else if(%obj.AIMode == 2){
               %obj.CurrentState=$NPC::PickPath;
               %obj.scheduleHandel= %obj.schedule(%obj.WaitTime, "think",%obj);
            }
         }
      case $NPC::Idle :
      case $NPC::Moving :
         if(%obj.CanAttack){
            %obj.CheckEnemy(%obj);
            %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
         }
      case $NPC::PickDestionation :
         %obj.WanderSomewhere(%obj);
         %obj.CurrentState=$NPC::Moving;
         %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
      case $NPC::Init :
         %obj.clearAim();
         if(%obj.Origin==0){
            %xfrm = %obj.getTransform();
            %charX=getWord(%xfrm,0);
            %charY=getWord(%xfrm,1);
            %obj.Origin=%xfrm;
            %obj.OriginX=%charX;
            %obj.OriginY=%charY;
         }else{
            %obj.setTransform(%obj.Origin);
         }
         %obj.setMoveSpeed(%obj.MovementSpeed);
         if(%obj.AIMode == 1 || %obj.AIMode == 2){
            %obj.CurrentState=$NPC::Waiting;
         }else{
            %obj.CurrentState=$NPC::StaticMode;
         }
         %obj.target=0;
         %obj.ViaPoint=0;
         %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
      case $NPC::ViaPoint :
         %distance = VectorDist( %obj.ViaPoint.getTransform(),%obj.getTransform() );
         if(%distance<1){
            %obj.setMoveDestination(%obj.target.getPosition(),true);
            %obj.CurrentState=$NPC::Attack;
         }
         %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
      case $NPC::JumpPoint :
         %distance = VectorDist( %obj.ViaPoint.getTransform(),%obj.getTransform() );
         if(%distance<2){
            %obj.setImageTrigger(2,true); 
            %obj.setMoveDestination(%obj.target.getPosition(),true);
            %obj.CurrentState=$NPC::Attack;
         }
         %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
      case $NPC::Captured :
         %obj.CurrentState=$NPC::Idle;
         %obj.startFade(2000, 0, true );
         %obj.scheduleHandel= %obj.schedule(%obj.RespawnTime, "respawn",%obj);
         //StartBattle?
      case $NPC::LostSite :
         cancel(%obj.scheduleHandel);
         %obj.setMoveSpeed(%obj.MovementSpeed);
         %obj.setMoveDestination(%obj.Origin,true);
         %obj.CurrentState=$NPC::Moving;
         %obj.setImageTrigger(0,false); //make it stop shoot 
      case $NPC::SetupMode :
         %obj.scheduleHandel= %obj.schedule(10000, "think",%obj);
      case $NPC::StaticMode :
         %obj.stopThread(1);
         %obj.setActionThread(%obj.StaticModePose, 
            false,//hold = false,  
            false//fsp = false,   
            );
            
         if(%obj.CanAttack){
            if(%obj.CheckEnemy(%obj)){
               %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
            }else if(%obj.StaticLoop){
               %obj.scheduleHandel= %obj.schedule(%obj.StaticLoopTime*1000, "think",%obj);
            }
         }else{
            if(%obj.StaticLoop){
               %obj.scheduleHandel= %obj.schedule(%obj.StaticLoopTime*1000, "think",%obj);
            }
         }
      case $NPC::PickPath :
         %obj.findNextPath(%obj);
         %obj.CurrentState=$NPC::Moving;
         %obj.scheduleHandel= %obj.schedule(%obj.ThinkSpeed, "think",%obj);
         
   }
}